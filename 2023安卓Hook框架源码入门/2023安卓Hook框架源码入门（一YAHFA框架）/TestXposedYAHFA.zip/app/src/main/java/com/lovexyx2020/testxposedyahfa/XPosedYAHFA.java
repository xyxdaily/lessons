package com.lovexyx2020.testxposedyahfa;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import lab.galaxy.yahfa.HookMain;

public class XPosedYAHFA implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
        if(loadPackageParam.packageName.equals("com.lovexyx2020.testforyahfahook")){
//            // 1. 找到类名 2. 找到方法名 3. 确认它的参数
//            XposedHelpers.findAndHookMethod("android.widget.TextView", loadPackageParam.classLoader, "setText", CharSequence.class, new XC_MethodHook() {
//                @Override
//                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
//                    // 修改参数在方法调用之前
//                    param.args[0] = "you are hooked by xposed";
//                    XposedBridge.log("called setText");
//                    super.beforeHookedMethod(param);
//                }
//                @Override
//                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    super.afterHookedMethod(param);
////                    param.setResult("");
//                    //
//                }
//            });

                Class<?> TextView = Class.forName("android.widget.TextView");
                Method setText = TextView.getDeclaredMethod("setText", CharSequence.class);
                Method setText_hook = XPosedYAHFA.class.getDeclaredMethod("setText_hook", Object.class, CharSequence.class);
                Method setText_backup = XPosedYAHFA.class.getDeclaredMethod("setText_backup", Object.class, CharSequence.class);
                HookMain.backupAndHook(setText,setText_hook,setText_backup);
        }
    }

    public static void setText_hook(Object obj,CharSequence charSequence){
        XposedBridge.log("called setText_hook");
        charSequence = "you are hooked by YAHFA";
        setText_backup(obj,charSequence);
//        retrun
    }

    public static void setText_backup(Object obj,CharSequence charSequence){
        XposedBridge.log("called setText_backup");
    }
}
